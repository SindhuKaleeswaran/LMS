import React from 'react'

export const sidebarData = [
    {
        title : "Home",
        link : "/home"
    },
    {
        title : "Customer Details",
        link : "/custDetail"
    },{
        title : "Add Customer",
        link : "/addCust"
    },{
        title : "Filter",
        link : "/filter"
    },
];
