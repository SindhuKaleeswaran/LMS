import './customer.css'
import { useState } from 'react'
import React from 'react';
import Axios from 'axios';

import {
  CDBSidebar,
  CDBSidebarContent,
  CDBSidebarFooter,
  CDBSidebarHeader,
  CDBSidebarMenu,
  CDBSidebarMenuItem,
} from 'cdbreact';
import { NavLink } from 'react-router-dom';


const UpdateEmi = () => {
  const [amort_id, setamort_id] = useState(0)
  const [amort_loan_id, setamort_loan_id] = useState(0)
  const [no_of_emi_paid,setno_of_emi_paid] = useState(0)
 
  

  const addInstallment =() => {
    Axios.post("http://localhost:3002/amort", {
      amort_id : amort_id,
      amort_loan_id : amort_loan_id,
      no_of_emi_paid : no_of_emi_paid,

    }).then(() => {
      console.log("success");
    })
 


    
  }
  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'scroll initial' }}>
      <CDBSidebar textColor="#fff" backgroundColor="#333">
        <CDBSidebarHeader prefix={<i className="fa fa-bars fa-large"></i>}>
          <a href="/" className="text-decoration-none" style={{ color: 'inherit' }}>
          Loan Management
          </a>
        </CDBSidebarHeader>

        <CDBSidebarContent className="sidebar-content">
          <CDBSidebarMenu>
          <NavLink exact to="/sidebar" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="home">Home</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/addCust" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="user">Add Customer</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/custDetail" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="table">Customer List</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/addLoan" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="chart-line">Avail New Loan</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/loanDetail" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="table">Loan List</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/repay" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="tree">EMI installment</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="columns">Logout</CDBSidebarMenuItem>
            </NavLink>

          </CDBSidebarMenu>
        </CDBSidebarContent>

        <CDBSidebarFooter style={{ textAlign: 'center' }}>

        </CDBSidebarFooter>
      </CDBSidebar>
      <div className='rightside'>
      
      <div className="details">
        <div className="information">
          <h3>Add Loan</h3>

          <label>EMI ID:</label> 
          <input type = 'number' onChange = {(event) => 
            {setamort_id(event.target.value);} 
            }/>
          <label>Loan ID:</label> 
          <input type = 'number' onChange = {(event) => 
            {setamort_loan_id(event.target.value);} 
            }/>
          <label>Number of installments:</label> 
          <input type = 'number' onChange = {(event) => 
            {setno_of_emi_paid(event.target.value);} 
            }/>
            
          <button onClick={addInstallment}>Update Installment</button>
        </div>
       
      </div>
  
  

  </div>

</div>
);
};
  
export default UpdateEmi;