import React from 'react'
import './customer.css';
import Axios from 'axios';
import {useState} from 'react';
import { NavLink } from 'react-router-dom';
import {
  CDBSidebar,
  CDBSidebarContent,
  CDBSidebarFooter,
  CDBSidebarHeader,
  CDBSidebarMenu,
  CDBSidebarMenuItem,
} from 'cdbreact';

const EmiDet = () => {
  const [EmiList, setEmiList] = useState([]);

  Axios.get("http://localhost:3002/getLoan").then((response) => {
    setEmiList(response.data);
  })

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'scroll initial' }}>
      <CDBSidebar textColor="#fff" backgroundColor="#333">
        <CDBSidebarHeader prefix={<i className="fa fa-bars fa-large"></i>}>
          <a href="/" className="text-decoration-none" style={{ color: 'inherit' }}>
          Loan Management
          </a>
        </CDBSidebarHeader>

        <CDBSidebarContent className="sidebar-content">
          <CDBSidebarMenu>
          <NavLink exact to="/sidebar" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="home">Home</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/addCust" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="user">Add Customer</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/custDetail" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="table">Customer List</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/addLoan" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="chart-line">Avail New Loan</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/loanDetail" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="table">Loan List</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/repay" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="tree">EMI installment</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="columns">Logout</CDBSidebarMenuItem>
            </NavLink>

          </CDBSidebarMenu>
        </CDBSidebarContent>

        <CDBSidebarFooter style={{ textAlign: 'center' }}>

        </CDBSidebarFooter>
      </CDBSidebar>
      <div className='rightside'>
      <div className='showInfo'>
          <h3 className='custdisp'>Loan Details</h3>
            <div>
                <table class="table table-striped">
                <thead>
                    <tr>
                    <th scope="col">EMI ID</th>
                    <th scope="col">Total EMI Amount</th>
                    <th scope="col">Total EMIs</th>
                    <th scope="col">Pending EMIs</th>
                    <th scope="col">Loan Amount</th>
                    <th scope="col">EMI per month</th>

                    </tr>
                </thead>
            
                <tbody>   
                {
                    EmiList.map((val,i) =>
                <tr key={i}>
                    
                    <td>{val.emi_loan_id}</td>
                    <td>{val.emi_amt}</td>
                    <td>{val.no_of_emi}</td>
                    <td>{val.pending_emi}</td>
                    <td>{val.emi_loan_amt}</td>
                    <td>{val.emi_pm}</td>

                  </tr>
                    
                    )
                }
                 
                  </tbody>
                </table>
              </div>
        </div>
      </div>

    </div>
  )
}

export default EmiDet;