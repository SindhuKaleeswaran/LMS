import './sidebar.css';
import React from "react";
import { sidebarData } from './sidebarData';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'

const SideBar = () => {
    return(

        <div className="dash">
            <ul className='sidebarList'>
                {sidebarData.map((val, key) => {
                    return(
                        <ul key={key} className='row' onClick={()=>{window.location.pathname = val.link}}>
                            <div>
                                {val.title}
                            </div>
                        </ul>
                    );
                })}
            </ul>
            
        </div>
    )
}

export default SideBar;