import './customer.css'
import { useState } from 'react'
import React from 'react';
import Axios from 'axios';

import {
  CDBSidebar,
  CDBSidebarContent,
  CDBSidebarFooter,
  CDBSidebarHeader,
  CDBSidebarMenu,
  CDBSidebarMenuItem,
} from 'cdbreact';
import { NavLink } from 'react-router-dom';


const InpDetails = () => {
  const [cust_name, setcust_name] = useState("")
  const [cust_id, setcust_id] = useState(0)
  const [gender, setgender] = useState("")
  const [age, setage] = useState(0)
  const [mobile, setmobile] = useState("")
  const [income, setincome] = useState(0)
  const [acc_no, setacc_no] = useState("")
  const [acc_bal, setacc_bal] = useState(0)
  const [branch, setbranch] = useState("")
 
  

  const addCust =() => {
    Axios.post("http://localhost:3002/create", {
      cust_name : cust_name,
      cust_id : cust_id,
      gender: gender,
      age : age,
      mobile : mobile,
      income : income,
      acc_no : acc_no,
      acc_bal : acc_bal,
      branch : branch,

    }).then(() => {
      console.log("success");
    })
  }
  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'scroll initial' }}>
      <CDBSidebar textColor="#fff" backgroundColor="#333">
        <CDBSidebarHeader prefix={<i className="fa fa-bars fa-large"></i>}>
          <a href="/" className="text-decoration-none" style={{ color: 'inherit' }}>
          Loan Management
          </a>
        </CDBSidebarHeader>

        <CDBSidebarContent className="sidebar-content">
          <CDBSidebarMenu>
          <NavLink exact to="/sidebar" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="home">Home</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/addCust" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="user">Add Customer</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/custDetail" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="table">Customer List</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/addLoan" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="chart-line">Avail New Loan</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/loanDetail" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="table">Loan List</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/repay" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="tree">EMI installment</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="columns">Logout</CDBSidebarMenuItem>
            </NavLink>

          </CDBSidebarMenu>
        </CDBSidebarContent>

        <CDBSidebarFooter style={{ textAlign: 'center' }}>

        </CDBSidebarFooter>
      </CDBSidebar>
      <div className='rightside'>
      
      <div className="details">
        <div className="information">
          <h3>Add Customers</h3>
          <label>Name:</label>
          < input type = 'text' onChange = {(event) => 
            {setcust_name(event.target.value);} 
            } />
          <label>Customer ID:</label> 
          <input type = 'number' onChange = {(event) => 
            {setcust_id(event.target.value);} 
            }/>
          <label>Gender:</label> 
          <input type = 'text' onChange = {(event) => 
            {setgender(event.target.value);} 
            }/>
          <label>Age:</label> 
          <input type = 'number' onChange = {(event) => 
            {setage(event.target.value);} 
            }/>
          <label>Mobile:</label> 
          <input type = 'text' onChange = {(event) => 
            {setmobile(event.target.value);} 
            }/>
            <label>Income:</label> 
            <input type = 'number' onChange = {(event) => 
            {setincome(event.target.value);} 
            }/>
            <label>Account Number:</label> 
            <input type = 'text' onChange = {(event) => 
            {setacc_no(event.target.value);} 
            }/>
            <label>Account Balance:</label> 
            <input type = 'number' onChange = {(event) => 
            {setacc_bal(event.target.value);} 
            }/>
            <label>Branch:</label> 
            <input type = 'text' onChange = {(event) => 
            {setbranch(event.target.value);} 
            }/>
          <button onClick={addCust}>Add Customer</button>
        </div>
       
      </div>
  
  

  </div>

</div>
);
};
  
export default InpDetails;