import './customer.css'
import { useState } from 'react'
import React from 'react';
import Axios from 'axios';

import {
  CDBSidebar,
  CDBSidebarContent,
  CDBSidebarFooter,
  CDBSidebarHeader,
  CDBSidebarMenu,
  CDBSidebarMenuItem,
} from 'cdbreact';
import { NavLink } from 'react-router-dom';


const LoanDetails = () => {
  const [cust_id, setcust_id] = useState(0)
  const [loan_id, setloan_id] = useState(0)
  const [loan_amt, setloan_amt] = useState(0)
  const [int_rate, setint_rate] = useState(0)
  const [duration, setduration] = useState(0)
  const [loan_type, setloan_type] = useState("")
 
  

  const addLoan =() => {
    Axios.post("http://localhost:3002/addloan", {
      cust_id : cust_id,
      loan_id : loan_id,
      loan_amt : loan_amt,
      int_rate : int_rate,
      duration : duration,
      loan_type : loan_type,

    }).then(() => {
      console.log("success");
    })
  }
  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'scroll initial' }}>
      <CDBSidebar textColor="#fff" backgroundColor="#333">
        <CDBSidebarHeader prefix={<i className="fa fa-bars fa-large"></i>}>
          <a href="/" className="text-decoration-none" style={{ color: 'inherit' }}>
          Loan Management
          </a>
        </CDBSidebarHeader>

        <CDBSidebarContent className="sidebar-content">
          <CDBSidebarMenu>
          <NavLink exact to="/sidebar" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="home">Home</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/addCust" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="user">Add Customer</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/custDetail" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="table">Customer List</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/addLoan" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="chart-line">Avail New Loan</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/loanDetail" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="table">Loan List</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/repay" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="tree">EMI installment</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="columns">Logout</CDBSidebarMenuItem>
            </NavLink>

          </CDBSidebarMenu>
        </CDBSidebarContent>

        <CDBSidebarFooter style={{ textAlign: 'center' }}>

        </CDBSidebarFooter>
      </CDBSidebar>
      <div className='rightside'>
      
      <div className="details">
        <div className="information">
          <h3>Add Loan</h3>

          <label>Customer ID:</label> 
          <input type = 'number' onChange = {(event) => 
            {setcust_id(event.target.value);} 
            }/>
          <label>Loan ID:</label> 
          <input type = 'number' onChange = {(event) => 
            {setloan_id(event.target.value);} 
            }/>
          <label>Loan Amount:</label> 
          <input type = 'number' onChange = {(event) => 
            {setloan_amt(event.target.value);} 
            }/>
          <label>Interest Rate:</label> 
          <input type = 'number' onChange = {(event) => 
            {setint_rate(event.target.value);} 
            }/>
            <label>Duration(in months):</label> 
            <input type = 'number' onChange = {(event) => 
            {setduration(event.target.value);} 
            }/>
            <label>Loan Type:</label> 
            <input type = 'text' onChange = {(event) => 
            {setloan_type(event.target.value);} 
            }/>
            
          <button onClick={addLoan}>Avail Loan</button>
        </div>
       
      </div>
  
  

  </div>

</div>
);
};
  
export default LoanDetails;