import './customer.css'
import { useState } from 'react'
import React from 'react';
import Axios from 'axios';

import {
  CDBSidebar,
  CDBSidebarContent,
  CDBSidebarFooter,
  CDBSidebarHeader,
  CDBSidebarMenu,
  CDBSidebarMenuItem,
} from 'cdbreact';
import { NavLink } from 'react-router-dom';


const DispDetails = () => {

  const [custList, setcustList] = useState([])

  //const disp = () => {
    //console.log(name+amt+aadhar+pan+intr+crd+apprv)
  //}



    Axios.get("http://localhost:3002/getCust").then((response) => {
      setcustList(response.data);
    })



  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'scroll initial' }}>
      <CDBSidebar textColor="#fff" backgroundColor="#333">
        <CDBSidebarHeader prefix={<i className="fa fa-bars fa-large"></i>}>
          <a href="/" className="text-decoration-none" style={{ color: 'inherit' }}>
          Loan Management
          </a>
        </CDBSidebarHeader>

        <CDBSidebarContent className="sidebar-content">
          <CDBSidebarMenu>
          <NavLink exact to="/sidebar" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="home">Home</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/addCust" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="user">Add Customer</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/custDetail" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="table">Customer List</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/addLoan" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="chart-line">Avail New Loan</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/loanDetail" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="table">Loan List</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/repay" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="tree">EMI installment</CDBSidebarMenuItem>
            </NavLink>
            <NavLink exact to="/" activeClassName="activeClicked">
              <CDBSidebarMenuItem icon="columns">Logout</CDBSidebarMenuItem>
            </NavLink>

          </CDBSidebarMenu>
        </CDBSidebarContent>

        <CDBSidebarFooter style={{ textAlign: 'center' }}>

        </CDBSidebarFooter>
      </CDBSidebar>
      <div className='rightside'>
      <div className='showInfo'>
          <h3 className='custdisp'>Customer Details</h3>
            <div>
                <table class="table table-striped">
                <thead>
                    <tr>
                    <th scope="col">Customer ID</th>
                    <th scope="col">Customer Name</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Age</th>
                    <th scope="col">Mobile</th>
                    <th scope="col">Income</th>
                    <th scope="col">Account Number</th>
                    <th scope="col">Account Balance</th>
                    <th scope="col">Branch</th>

                    </tr>
                </thead>
            
                <tbody>   
                {
                    custList.map((val,i) =>
                <tr key={i}>
                    
                    <td>{val.cust_id}</td>
                    <td>{val.cust_name}</td>
                    <td>{val.gender}</td>
                    <td>{val.age}</td>
                    <td>{val.mobile}</td>
                    <td>{val.income}</td>
                    <td>{val.acc_no}</td>
                    <td>{val.acc_bal}</td>
                    <td>{val.branch}</td>

                  </tr>
                    
                    )
                }
                 
                  </tbody>
                </table>
              </div>
        </div>
      </div>

    </div>
  );
};

  
  export default DispDetails;